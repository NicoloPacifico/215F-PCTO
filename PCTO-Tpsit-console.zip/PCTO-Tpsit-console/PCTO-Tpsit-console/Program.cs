﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Data;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Specialized;
using System.Collections.ObjectModel;
using System.Text.Json.Serialization;
using System.Text.Json;

namespace PCTO_Tpsit_console
{
    class HttpServer
    {
        public static HttpListener listener;
        public static string stringaJson1 = "";
        public static string url = "http://localhost:8000/";
        public static int pageViews = 0;
        public static int requestCount = 0;
        public static string pageData =
            "<!DOCTYPE>" +
            "<html>" +
            "  <head>" +
            "    <title>HttpListener Example</title>" +
            "  </head>" +
            "  <body>" +
            "    <p>Page Views: {0}</p>" +
            "    <form method=\"post\" action=\"shutdown\">" +
            "      <input type=\"submit\" value=\"Shutdown\" {1}>" +
            "    </form>" +
            "  </body>" +
            "</html>";


        public static async Task HandleIncomingConnections()
        {
            bool runServer = true;

            //Continua a stare in ascolto finchè qualcuno non si collega
            while (runServer)
            {
                HttpListenerContext ctx = await listener.GetContextAsync();

                //Stabilisco richiesta e risposta
                HttpListenerRequest req = ctx.Request;
                HttpListenerResponse resp = ctx.Response;

                //Stampa a console le richieste
                Console.WriteLine("Richiesta numero: {0}", ++requestCount);
                Console.WriteLine(req.Url.ToString());
                Console.WriteLine(req.HttpMethod);
                Console.WriteLine(req.UserHostName);
                Console.WriteLine(req.UserAgent);
                Console.WriteLine();

                if ((req.HttpMethod == "POST") && (req.Url.AbsolutePath == "/shutdown"))
                {
                    Console.WriteLine("Shutdown requested");
                    runServer = false;
                }

                if (req.Url.AbsolutePath != "/favicon.ico")
                    pageViews += 1;

                //Stampa a console la risposta
                string disableSubmit = !runServer ? "disabled" : "";
                byte[] data = Encoding.UTF8.GetBytes(String.Format(pageData, pageViews, disableSubmit));
                resp.ContentType = "text/html";
                resp.ContentEncoding = Encoding.UTF8;
                resp.ContentLength64 = data.LongLength;

                await resp.OutputStream.WriteAsync(data, 0, data.Length);
                resp.Close();
            }
        }


        public static void Main(string[] args)
        {
            //Crea un server HTTP e rimane in ascolto per le varie connessioni
            listener = new HttpListener();
            listener.Prefixes.Add(url);
            listener.Start();
            Console.WriteLine("Listening for connections on {0}", url);

            //Gestisci le richieste
            Task listenTask = HandleIncomingConnections();
            listenTask.GetAwaiter().GetResult();

            //Chiudo il listener
            listener.Close();
        }

        public void JsonSerialization()
        {
            StringaJson stringaJson = new StringaJson();
            string jsonString = JsonSerializer.Serialize(stringaJson);
            jsonString = JsonSerializer.Serialize(stringaJson);
            File.WriteAllText("file.txt", jsonString);
            jsonString = JsonSerializer.Serialize<StringaJson>(stringaJson);
        }

        public void LetturaJson()
        {
            int count = 0;
            int count2 = 0;
            int inOrOut = 0;
            int nRecords = 1;
            JsonTextReader reader = new JsonTextReader(new StreamReader(stringaJson1));
            string[] rawData = new string[5];
            while (reader.Read())
            {
                if (reader.Value != null)
                    if (inOrOut == 1)
                    {
                        if (count == 6)
                        {
                            nRecords++;
                            Array.Resize(ref rawData, nRecords);
                            //textBox1.Text += "\r\n";
                            count = 0;
                        }
                        rawData[count2] += reader.Value + ","; //+"\r\n"
                        inOrOut = 0;
                        count++;
                        if (count2 == 500)
                        {
                            Console.WriteLine(rawData[499]);
                        }
                    }
                    else
                    {
                        inOrOut = 1;
                    }
            }
        }
    }

    public class StringaJson
    {
        public string NomeProdotto { get; set; }
        public string Descrizione { get; set; }
    }

    public class JsonTextReader
    {
        public string Value { get; set; }
        public JsonTextReader(StreamReader sr)
        {

        }

        public bool Read()
        {
            return true;
        }
    }
}
