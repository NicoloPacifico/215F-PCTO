﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Connection
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlConnection con= new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\Giacomo\source\repos\tpsit\tpsit\Moduli.mdf;Integrated Security = True");
           
            //SqlCommand cmd = new SqlCommand(query, con);


            try
            {
                con.Open();
               //cmd.ExecuteNonQuery();
                Console.WriteLine("Record inserito con successo!");


            }
            catch(SqlException e)
            {
                Console.WriteLine("Error");
            }
            finally
            {
                con.Close();
                Console.ReadKey();
            }
        }
    }
}
