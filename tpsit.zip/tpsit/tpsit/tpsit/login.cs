﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace tpsit
{
    public partial class login : Form
    {
        SqlConnection Database = new SqlConnection(@"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=C:\Users\Giacomo\Desktop\tpsit\tpsit\Moduli.mdf;Integrated Security = True");
        public login()
        {
            InitializeComponent();
        }
        /// <summary>
        /// BOTTONE PER LOGGARSI
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void button1_Click(object sender, EventArgs e)
        {
            int i = 0;
            SqlCommand comand = Database.CreateCommand();
            comand.CommandType = CommandType.Text;
            comand.CommandText = "select * from Table2 where username= '" + textBox1.Text + "' and password='" + textBox2.Text + "'";
            comand.ExecuteNonQuery();
            DataTable dt = new DataTable();
            SqlDataAdapter da = new SqlDataAdapter(comand);
            da.Fill(dt);
            i = Convert.ToInt32(dt.Rows.Count.ToString());
            if(i==0)
            {
                MessageBox.Show("queste credenziali non sono state trovate");
                this.Close();
            }
            else
            {
                this.Hide();
                MDIParent1 mdi = new MDIParent1();
                mdi.Show();
            }
        }

        private void login_Load(object sender, EventArgs e)
        {
            if(Database.State==ConnectionState.Open)
            {
                Database.Close();
            }
            Database.Open();

        }
    }
}
